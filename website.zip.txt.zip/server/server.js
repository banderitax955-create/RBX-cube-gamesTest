
import express from "express";
import fs from "fs";

const app = express();
app.use(express.json());

const DB_PATH = "./db.json";

const readDB = () => JSON.parse(fs.readFileSync(DB_PATH));
const writeDB = (data) => fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));

// webhook
app.post("/webhook", (req, res) => {
  const event = req.body;
  if (event.event_type === "transaction.completed") {
    const db = readDB();
    const data = event.data;

    db.purchases.push({
      userId: data.custom_data?.userId,
      templateId: data.custom_data?.templateId
    });

    writeDB(db);
  }
  res.sendStatus(200);
});

// get purchases
app.get("/purchases", (req, res) => {
  res.json(readDB().purchases);
});

// rating
app.post("/rate", (req, res) => {
  const db = readDB();
  db.ratings.push(req.body);
  writeDB(db);
  res.sendStatus(200);
});

// codes
app.post("/code", (req, res) => {
  const db = readDB();
  db.codes.push(req.body);
  writeDB(db);
  res.sendStatus(200);
});

app.delete("/code/:code", (req, res) => {
  const db = readDB();
  db.codes = db.codes.filter(c => c.code !== req.params.code);
  writeDB(db);
  res.sendStatus(200);
});

app.listen(3001, () => console.log("Server running 3001"));
