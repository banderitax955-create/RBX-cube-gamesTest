
export const getPurchases = async () => {
  const res = await fetch("http://localhost:3001/purchases");
  return res.json();
};

export const submitRating = async (data) => {
  await fetch("http://localhost:3001/rate", {
    method: "POST",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify(data),
  });
};
