
export default function PaddleInput({value, setValue}) {
  return (
    <input
      placeholder="Paddle Price ID"
      value={value}
      onChange={(e)=>setValue(e.target.value)}
    />
  );
}
