
# Roblox Template Marketplace

A modern marketplace for selling Roblox game templates. Starts completely empty — all content is added through the admin panel. Built on TanStack Start (the stack this project uses — Next.js isn't supported here, but functionality is equivalent), Lovable Cloud (Postgres + Auth + Storage), and Stripe.

## Tech stack (adapted from your spec)

- **Framework**: TanStack Start + React (this project's stack; equivalent to Next.js for your needs)
- **Backend**: TanStack server functions + server routes (API routes)
- **Database + Auth + Storage**: Lovable Cloud (Postgres, managed auth, file storage)
- **Payments**: Stripe Checkout via Lovable's built-in seamless Stripe integration (no keys to paste)

## Design direction

Clean, modern dark UI with a gamer/Roblox-adjacent feel: near-black background, vibrant accent (electric blue/purple), rounded cards, subtle glow on primary CTAs, generous spacing. Sans-serif system stack with tighter tracking on headings.

## Pages & routes

Public:
- `/` — Homepage: hero + featured templates grid (empty state: "No templates yet")
- `/store` — Browse all templates with search + category/price filters (works while empty)
- `/templates/$id` — Template detail: thumbnail, screenshots, YouTube embed, Roblox test link, Buy button
- `/submit` — Submit Your Template form (free-template offer copy)
- `/community` — Community Games feed + submit-a-link form
- `/auth` — Login / Register (email + password, Google sign-in)

Authenticated:
- `/dashboard` — My purchases (with secure download) + my submissions status
- `/checkout/success` — Post-Stripe confirmation
- `/checkout/cancel`

Admin (gated by `has_role('admin')`, but every user is auto-granted admin for now):
- `/admin` — Stats dashboard (revenue, users, purchases, submissions, shared games)
- `/admin/templates` — CRUD templates (upload file, thumbnail, screenshots, video link, price)
- `/admin/submissions` — Review submitted templates, download files, approve/reject
- `/admin/community` — Moderate community game links
- `/admin/users` — List users + their purchases

## Database schema (Lovable Cloud)

- `profiles` (id → auth.users, display_name, discord_username, created_at)
- `user_roles` (id, user_id, role: enum 'admin'|'user') + `has_role()` security-definer fn
- `templates` (id, title, slug, description, price_cents, thumbnail_url, screenshots[], youtube_url, roblox_game_url, file_path, is_published, created_at)
- `template_submissions` (id, user_id, title, description, file_path, discord_username, game_idea, status: 'pending'|'approved'|'rejected', created_at)
- `community_games` (id, user_id, roblox_url, description, game_idea, created_at)
- `orders` (id, user_id, template_id, stripe_session_id, amount_cents, status: 'pending'|'paid'|'failed', created_at)

Storage buckets:
- `template-files` (private) — sold template files
- `template-images` (public) — thumbnails + screenshots
- `submissions` (private) — user-submitted files, admin-download only

RLS: users read/write own submissions, orders, community posts; templates public-read when `is_published`; admins bypass via `has_role`. Grants added per public-schema rules.

## Uploads & validation

- Submissions accept `.rbxl`, `.rbxlx`, `.rbxm` only, max 100 MB — validated client-side AND in the server function before upload.
- Zod schemas on every form (title/description length caps, Discord `@username` regex, URL validation for Roblox links).

## Payments (Stripe)

- Enable Lovable's built-in seamless Stripe integration (no API keys required from you).
- Products created per template via admin panel; `Buy` button calls a server fn that creates a Stripe Checkout session.
- Public `/api/public/webhooks/stripe` route verifies signature → marks order `paid` → grants download access.
- Download route issues a short-lived signed URL from the private `template-files` bucket, only if the user owns a paid order for that template.
- No card data ever touches the app.

## Security

- Auth-gated downloads via server function + signed URLs (60s expiry).
- Webhook signature verification (HMAC, timing-safe).
- Zod validation server-side on all inputs.
- RLS on every table; `service_role` used only in verified webhook.
- Roles stored in separate `user_roles` table (never on profiles) — per platform security rules.
- For testing: a DB trigger grants `admin` role to every new signup. To restrict later, remove the trigger and manually assign roles — no code changes needed.

## Build order

1. Enable Lovable Cloud
2. Migrations: schema, RLS, grants, `has_role`, auto-admin trigger, storage buckets
3. Design system tokens in `styles.css` (dark theme + accent)
4. Auth pages + root layout with nav (session-aware)
5. Public pages (home, store, template detail, community, submit) — all with empty states
6. User dashboard
7. Admin panel (all 4 managers + stats)
8. Enable Stripe payments + checkout + webhook + secure download
9. SEO metadata per route, sitemap, robots

Ready to build?
