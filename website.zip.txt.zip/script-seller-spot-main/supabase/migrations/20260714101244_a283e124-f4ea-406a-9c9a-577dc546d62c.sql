
CREATE TABLE public.genres (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.genres TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.genres TO authenticated;
GRANT ALL ON public.genres TO service_role;
ALTER TABLE public.genres ENABLE ROW LEVEL SECURITY;
CREATE POLICY "genres readable by all" ON public.genres FOR SELECT USING (true);
CREATE POLICY "genres writable by auth (test)" ON public.genres FOR ALL TO authenticated USING (true) WITH CHECK (true);

ALTER TABLE public.templates ADD COLUMN IF NOT EXISTS genre_id UUID REFERENCES public.genres(id) ON DELETE SET NULL;

CREATE TABLE public.site_texts (
  key TEXT NOT NULL PRIMARY KEY,
  value TEXT NOT NULL DEFAULT '',
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.site_texts TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.site_texts TO authenticated;
GRANT ALL ON public.site_texts TO service_role;
ALTER TABLE public.site_texts ENABLE ROW LEVEL SECURITY;
CREATE POLICY "site_texts readable by all" ON public.site_texts FOR SELECT USING (true);
CREATE POLICY "site_texts writable by auth (test)" ON public.site_texts FOR ALL TO authenticated USING (true) WITH CHECK (true);
