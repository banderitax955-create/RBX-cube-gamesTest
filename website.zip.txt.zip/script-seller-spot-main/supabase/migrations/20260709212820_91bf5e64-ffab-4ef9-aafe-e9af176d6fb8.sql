
REVOKE EXECUTE ON FUNCTION public.has_role(UUID, public.app_role) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.has_role(UUID, public.app_role) TO service_role;

REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM PUBLIC, anon, authenticated;

-- Storage policies: template-files (private, admin manage; users read only via server fn signed URLs)
CREATE POLICY "template-files admin all" ON storage.objects
FOR ALL TO authenticated
USING (bucket_id = 'template-files' AND public.has_role(auth.uid(), 'admin'))
WITH CHECK (bucket_id = 'template-files' AND public.has_role(auth.uid(), 'admin'));

-- template-images (private but readable by admins; server fn issues signed URLs for display)
CREATE POLICY "template-images admin all" ON storage.objects
FOR ALL TO authenticated
USING (bucket_id = 'template-images' AND public.has_role(auth.uid(), 'admin'))
WITH CHECK (bucket_id = 'template-images' AND public.has_role(auth.uid(), 'admin'));

-- submissions (users upload own; admins read/delete)
CREATE POLICY "submissions user upload" ON storage.objects
FOR INSERT TO authenticated
WITH CHECK (bucket_id = 'submissions' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "submissions user read own" ON storage.objects
FOR SELECT TO authenticated
USING (bucket_id = 'submissions' AND (auth.uid()::text = (storage.foldername(name))[1] OR public.has_role(auth.uid(), 'admin')));

CREATE POLICY "submissions admin delete" ON storage.objects
FOR DELETE TO authenticated
USING (bucket_id = 'submissions' AND public.has_role(auth.uid(), 'admin'));
