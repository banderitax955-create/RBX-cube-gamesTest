import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { SiteHeader } from "@/components/site-header";
import { listMyOrders, getPurchaseDownloadUrl } from "@/lib/orders.functions";
import { listMySubmissions } from "@/lib/submissions.functions";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { formatPrice } from "@/lib/format";
import { Download, Package, FileUp } from "lucide-react";

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({ meta: [{ title: "Dashboard — RBX Cube Games" }] }),
  component: Dashboard,
});

function Dashboard() {
  const ordersFn = useServerFn(listMyOrders);
  const subsFn = useServerFn(listMySubmissions);
  const { data: orders = [] } = useQuery({ queryKey: ["my-orders"], queryFn: () => ordersFn() });
  const { data: subs = [] } = useQuery({ queryKey: ["my-subs"], queryFn: () => subsFn() });

  const dlFn = useServerFn(getPurchaseDownloadUrl);
  const download = useMutation({
    mutationFn: (template_id: string) => dlFn({ data: { template_id } }),
    onSuccess: (r) => { window.location.href = r.url; },
    onError: (e) => toast.error(e instanceof Error ? e.message : "Failed"),
  });

  return (
    <div className="min-h-screen"><SiteHeader />
      <main className="mx-auto max-w-6xl px-4 py-10 space-y-10">
        <div>
          <h1 className="text-3xl font-bold">Your dashboard</h1>
          <p className="mt-1 text-muted-foreground">Purchased templates and your submissions.</p>
        </div>

        <section>
          <h2 className="mb-4 text-xl font-semibold flex items-center gap-2"><Package className="h-5 w-5" /> Purchased templates</h2>
          {orders.length === 0 ? (
            <Card><CardContent className="py-10 text-center text-muted-foreground">
              No purchases yet. <Link to="/store" className="text-primary">Browse the store</Link>.
            </CardContent></Card>
          ) : (
            <div className="grid gap-3">
              {orders.map((o) => {
                const tpl = (o as unknown as { templates?: { title?: string; slug?: string } }).templates;
                return (
                  <Card key={o.id}>
                    <CardContent className="flex items-center justify-between gap-3 p-4">
                      <div>
                        <p className="font-medium">{tpl?.title ?? "Template"}</p>
                        <p className="text-xs text-muted-foreground">{formatPrice(o.amount_cents)} · {o.status}</p>
                      </div>
                      <div className="flex gap-2">
                        {tpl?.slug && <Button asChild size="sm" variant="ghost"><Link to="/templates/$slug" params={{ slug: tpl.slug }}>View</Link></Button>}
                        <Button size="sm" disabled={download.isPending} onClick={() => download.mutate(o.template_id)}>
                          <Download className="mr-1.5 h-4 w-4" /> Download
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </section>

        <section>
          <h2 className="mb-4 text-xl font-semibold flex items-center gap-2"><FileUp className="h-5 w-5" /> Your submissions</h2>
          {subs.length === 0 ? (
            <Card><CardContent className="py-10 text-center text-muted-foreground">
              No submissions yet. <Link to="/submit" className="text-primary">Submit a template</Link>.
            </CardContent></Card>
          ) : (
            <div className="grid gap-3">
              {subs.map((s) => (
                <Card key={s.id}>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-base">{s.title}</CardTitle>
                    <Badge variant={s.status === "approved" ? "default" : s.status === "rejected" ? "destructive" : "secondary"}>{s.status}</Badge>
                  </CardHeader>
                  <CardContent className="pb-4 pt-0 text-sm text-muted-foreground">
                    <p>{s.description || "No description"}</p>
                    <p className="mt-1 text-xs">Discord: {s.discord_username} · File: {s.file_name}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </section>
      </main>
    </div>
  );
}
