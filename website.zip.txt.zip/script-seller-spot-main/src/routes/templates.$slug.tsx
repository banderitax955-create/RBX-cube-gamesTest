import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { SiteHeader } from "@/components/site-header";
import { getTemplateBySlug, deleteTemplate } from "@/lib/templates.functions";
import { purchaseTemplateTestMode } from "@/lib/orders.functions";
import { useSession } from "@/hooks/use-session";
import { Button } from "@/components/ui/button";
import { formatPrice } from "@/lib/format";
import { Package, ShoppingCart, Trash2 } from "lucide-react";

export const Route = createFileRoute("/templates/$slug")({
  component: TemplateDetail,
});

function TemplateDetail() {
  const { slug } = Route.useParams();
  const { user } = useSession();
  const navigate = useNavigate();
  const fn = useServerFn(getTemplateBySlug);
  const { data: t, isLoading } = useQuery({ queryKey: ["template", slug], queryFn: () => fn({ data: { slug } }) });

  const buyFn = useServerFn(purchaseTemplateTestMode);
  const buy = useMutation({
    mutationFn: () => buyFn({ data: { template_id: t!.id } }),
    onSuccess: () => { toast.success("Purchased! Available in your dashboard."); navigate({ to: "/dashboard" }); },
    onError: (e) => toast.error(e instanceof Error ? e.message : "Failed"),
  });

  const delFn = useServerFn(deleteTemplate);
  const del = useMutation({
    mutationFn: () => delFn({ data: { id: t!.id } }),
    onSuccess: () => { toast.success("Template deleted"); navigate({ to: "/store" }); },
    onError: (e) => toast.error(e instanceof Error ? e.message : "Failed"),
  });

  if (isLoading) return <div className="min-h-screen"><SiteHeader /><div className="mx-auto max-w-6xl px-4 py-16 animate-pulse">Loading…</div></div>;
  if (!t) return (
    <div className="min-h-screen"><SiteHeader />
      <div className="mx-auto max-w-6xl px-4 py-16 text-center">
        <h1 className="text-2xl font-semibold">Template not found</h1>
        <Link to="/store" className="mt-4 inline-block text-primary">Back to store</Link>
      </div>
    </div>
  );

  const ytId = t.youtube_url?.match(/(?:v=|youtu\.be\/|embed\/)([A-Za-z0-9_-]{11})/)?.[1];

  return (
    <div className="min-h-screen">
      <SiteHeader />
      <main className="mx-auto max-w-6xl px-4 py-10">
        <div className="grid gap-8 lg:grid-cols-3">
          <div className="lg:col-span-2 space-y-6">
            <div className="aspect-video overflow-hidden rounded-xl border border-border bg-card">
              {t.thumbnail_signed ? (
                <img src={t.thumbnail_signed} alt={t.title} className="h-full w-full object-cover" />
              ) : <div className="flex h-full items-center justify-center text-muted-foreground"><Package className="h-10 w-10" /></div>}
            </div>
            {t.screenshots_signed.length > 0 && (
              <div className="grid grid-cols-3 gap-2">
                {t.screenshots_signed.map((s, i) => (
                  <img key={i} src={s} alt={`Screenshot ${i + 1}`} className="aspect-video w-full rounded-lg border border-border object-cover" />
                ))}
              </div>
            )}
            {ytId && (
              <div className="aspect-video overflow-hidden rounded-xl border border-border">
                <iframe className="h-full w-full" src={`https://www.youtube.com/embed/${ytId}`} title="Demo" allowFullScreen />
              </div>
            )}
            <div>
              <h2 className="text-lg font-semibold">About this template</h2>
              <p className="mt-2 whitespace-pre-wrap text-muted-foreground">{t.description || "No description."}</p>
            </div>
          </div>

          <aside className="space-y-4">
            <div className="rounded-xl border border-border bg-card p-5">
              <h1 className="text-2xl font-bold">{t.title}</h1>
              <div className="mt-3 text-3xl font-bold text-primary">{formatPrice(t.price_cents)}</div>
              {user ? (
                <Button className="mt-5 w-full" size="lg" disabled={buy.isPending} onClick={() => buy.mutate()}>
                  <ShoppingCart className="mr-2 h-4 w-4" /> {buy.isPending ? "Processing…" : "Buy now"}
                </Button>
              ) : (
                <Button asChild className="mt-5 w-full" size="lg">
                  <Link to="/auth">Sign in to buy</Link>
                </Button>
              )}
              {user && (
                <Button
                  variant="ghost"
                  className="mt-3 w-full text-destructive hover:text-destructive"
                  onClick={() => confirm("Delete this template permanently?") && del.mutate()}
                >
                  <Trash2 className="mr-2 h-4 w-4" /> Delete template
                </Button>
              )}
              <p className="mt-4 text-xs text-muted-foreground">Instant download after purchase.</p>
            </div>
          </aside>
        </div>
      </main>
    </div>
  );
}
