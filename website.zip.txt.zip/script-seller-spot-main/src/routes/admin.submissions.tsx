import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { listAllSubmissionsAdmin, setSubmissionStatus, getSubmissionDownloadUrl } from "@/lib/submissions.functions";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Check, Download, X } from "lucide-react";

export const Route = createFileRoute("/admin/submissions")({
  component: AdminSubs,
});

function AdminSubs() {
  const qc = useQueryClient();
  const listFn = useServerFn(listAllSubmissionsAdmin);
  const { data: subs = [] } = useQuery({ queryKey: ["admin-subs"], queryFn: () => listFn() });

  const statusFn = useServerFn(setSubmissionStatus);
  const setStatus = useMutation({
    mutationFn: (v: { id: string; status: "approved" | "rejected" | "pending" }) => statusFn({ data: v }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["admin-subs"] }),
  });

  const dlFn = useServerFn(getSubmissionDownloadUrl);
  const download = useMutation({
    mutationFn: (id: string) => dlFn({ data: { id } }),
    onSuccess: (r) => { window.location.href = r.url; },
    onError: (e) => toast.error(e instanceof Error ? e.message : "Failed"),
  });

  return (
    <div className="space-y-6">
      <div><h1 className="text-2xl font-bold">Submissions</h1><p className="text-sm text-muted-foreground">Review templates submitted by users.</p></div>
      {subs.length === 0 ? (
        <Card><CardContent className="py-16 text-center text-muted-foreground">No submissions yet.</CardContent></Card>
      ) : (
        <div className="grid gap-3">
          {subs.map((s) => (
            <Card key={s.id}>
              <CardContent className="p-4 space-y-3">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <p className="font-medium">{s.title}</p>
                      <Badge variant={s.status === "approved" ? "default" : s.status === "rejected" ? "destructive" : "secondary"}>{s.status}</Badge>
                    </div>
                    <p className="mt-1 text-sm text-muted-foreground">{s.description || "No description"}</p>
                    {s.game_idea && <p className="mt-1 text-sm"><span className="text-muted-foreground">Idea:</span> {s.game_idea}</p>}
                    <p className="mt-2 text-xs text-muted-foreground">Discord: <span className="text-foreground">{s.discord_username}</span> · {s.file_name} · {(s.file_size / 1024 / 1024).toFixed(2)} MB</p>
                  </div>
                </div>
                <div className="flex flex-wrap gap-2">
                  <Button size="sm" variant="secondary" onClick={() => download.mutate(s.id)}><Download className="mr-1.5 h-4 w-4" /> Download file</Button>
                  <Button size="sm" onClick={() => setStatus.mutate({ id: s.id, status: "approved" })}><Check className="mr-1.5 h-4 w-4" /> Approve</Button>
                  <Button size="sm" variant="destructive" onClick={() => setStatus.mutate({ id: s.id, status: "rejected" })}><X className="mr-1.5 h-4 w-4" /> Reject</Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
