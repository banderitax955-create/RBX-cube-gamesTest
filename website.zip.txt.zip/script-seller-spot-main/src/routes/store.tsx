import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useState, useMemo } from "react";
import { SiteHeader } from "@/components/site-header";
import { listPublishedTemplates } from "@/lib/templates.functions";
import { listGenres } from "@/lib/genres.functions";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { Package, Search, Tag } from "lucide-react";
import { TemplateCard } from "@/routes/index";
import { useTexts } from "@/hooks/use-texts";

export const Route = createFileRoute("/store")({
  head: () => ({ meta: [{ title: "Store — RBX Cube Games" }, { name: "description", content: "Browse all Roblox game templates." }] }),
  component: Store,
});

function Store() {
  const fn = useServerFn(listPublishedTemplates);
  const genresFn = useServerFn(listGenres);
  const { data: templates = [], isLoading } = useQuery({ queryKey: ["templates"], queryFn: () => fn() });
  const { data: genres = [] } = useQuery({ queryKey: ["genres"], queryFn: () => genresFn() });
  const t = useTexts();
  const [q, setQ] = useState("");
  const [sort, setSort] = useState<"new" | "price-asc" | "price-desc">("new");
  const [priceRange, setPriceRange] = useState<"all" | "free" | "under10" | "under25" | "over25">("all");
  const [genreId, setGenreId] = useState<string>("all");

  const filtered = useMemo(() => {
    let list = templates.filter((tpl) => tpl.title.toLowerCase().includes(q.toLowerCase()) || (tpl.description ?? "").toLowerCase().includes(q.toLowerCase()));
    if (genreId !== "all") list = list.filter((tpl) => tpl.genre_id === genreId);
    if (priceRange === "free") list = list.filter((tpl) => tpl.price_cents === 0);
    if (priceRange === "under10") list = list.filter((tpl) => tpl.price_cents > 0 && tpl.price_cents < 1000);
    if (priceRange === "under25") list = list.filter((tpl) => tpl.price_cents >= 1000 && tpl.price_cents < 2500);
    if (priceRange === "over25") list = list.filter((tpl) => tpl.price_cents >= 2500);
    if (sort === "price-asc") list = [...list].sort((a, b) => a.price_cents - b.price_cents);
    if (sort === "price-desc") list = [...list].sort((a, b) => b.price_cents - a.price_cents);
    return list;
  }, [templates, q, sort, priceRange, genreId]);

  const countFor = (id: string) => templates.filter((tpl) => tpl.genre_id === id).length;

  return (
    <div className="min-h-screen">
      <SiteHeader />
      <main className="mx-auto max-w-7xl px-4 py-10">
        <div className="mb-8">
          <h1 className="text-3xl font-bold">{t("store_title")}</h1>
          <p className="mt-1 text-muted-foreground">{t("store_subtitle")}</p>
        </div>

        <div className="mb-6">
          <div className="mb-2 flex items-center gap-2 text-sm font-medium">
            <Tag className="h-4 w-4 text-primary" /> Genres
          </div>
          {genres.length === 0 ? (
            <p className="text-sm text-muted-foreground">No genres yet. Admins can add genres from the admin panel.</p>
          ) : (
            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => setGenreId("all")}
                className={`rounded-full border px-3 py-1 text-xs transition-colors ${genreId === "all" ? "border-primary bg-primary/15 text-primary" : "border-border text-muted-foreground hover:border-primary/50 hover:text-foreground"}`}
              >
                All <span className="opacity-60">({templates.length})</span>
              </button>
              {genres.map((g) => (
                <button
                  key={g.id}
                  onClick={() => setGenreId(g.id)}
                  className={`rounded-full border px-3 py-1 text-xs transition-colors ${genreId === g.id ? "border-primary bg-primary/15 text-primary" : "border-border text-muted-foreground hover:border-primary/50 hover:text-foreground"}`}
                >
                  {g.name} <span className="opacity-60">({countFor(g.id)})</span>
                </button>
              ))}
            </div>
          )}
        </div>

        <div className="mb-6 flex flex-wrap gap-3">
          <div className="relative flex-1 min-w-64">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search templates…" className="pl-9" />
          </div>
          <Select value={priceRange} onValueChange={(v) => setPriceRange(v as typeof priceRange)}>
            <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Any price</SelectItem>
              <SelectItem value="free">Free</SelectItem>
              <SelectItem value="under10">Under $10</SelectItem>
              <SelectItem value="under25">$10–$25</SelectItem>
              <SelectItem value="over25">$25+</SelectItem>
            </SelectContent>
          </Select>
          <Select value={sort} onValueChange={(v) => setSort(v as typeof sort)}>
            <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="new">Newest</SelectItem>
              <SelectItem value="price-asc">Price ↑</SelectItem>
              <SelectItem value="price-desc">Price ↓</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {isLoading ? (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {Array.from({ length: 6 }).map((_, i) => <div key={i} className="h-64 animate-pulse rounded-xl bg-card/50" />)}
          </div>
        ) : filtered.length === 0 ? (
          <Card>
            <CardContent className="flex flex-col items-center justify-center py-20 text-center">
              <Package className="mb-4 h-10 w-10 text-muted-foreground" />
              <h3 className="text-lg font-medium">{templates.length === 0 ? "No templates yet" : "No matches"}</h3>
              <p className="mt-1 text-sm text-muted-foreground">{templates.length === 0 ? "New templates are on the way." : "Try adjusting your filters."}</p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {filtered.map((tpl) => <TemplateCard key={tpl.id} t={tpl} />)}
          </div>
        )}
      </main>
    </div>
  );
}
