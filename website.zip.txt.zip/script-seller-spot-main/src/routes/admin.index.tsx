import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { getAdminStats, listPendingSubmissionsAdmin, deleteSubmissionAdmin } from "@/lib/admin.functions";
import { getSubmissionDownloadUrl } from "@/lib/submissions.functions";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { formatPrice } from "@/lib/format";
import { toast } from "sonner";
import {
  DollarSign, Users, ShoppingBag, Download, FileUp, Boxes, TrendingUp, Trash2, Inbox,
  Wifi, WifiOff,
} from "lucide-react";

export const Route = createFileRoute("/admin/")({
  component: AdminHome,
});

type PendingSub = {
  id: string;
  title: string;
  description: string | null;
  discord_username: string;
  game_idea: string | null;
  status: string;
  created_at: string;
  file_name: string | null;
  user_id: string | null;
};

function AdminHome() {
  const statsFn = useServerFn(getAdminStats);
  const pendingFn = useServerFn(listPendingSubmissionsAdmin);
  const deleteFn = useServerFn(deleteSubmissionAdmin);
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [selected, setSelected] = useState<PendingSub | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<PendingSub | null>(null);

  const { data } = useQuery({ queryKey: ["admin-stats"], queryFn: () => statsFn() });
  const { data: pending } = useQuery({ queryKey: ["admin-pending-subs"], queryFn: () => pendingFn() });

  const del = useMutation({
    mutationFn: (id: string) => deleteFn({ data: { id } }),
    onSuccess: () => {
      toast.success("Submission removed");
      qc.invalidateQueries({ queryKey: ["admin-pending-subs"] });
      qc.invalidateQueries({ queryKey: ["admin-stats"] });
      setConfirmDelete(null);
      setSelected(null);
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const dlFn = useServerFn(getSubmissionDownloadUrl);
  const download = useMutation({
    mutationFn: (id: string) => dlFn({ data: { id } }),
    onSuccess: (r) => { window.open(r.url, "_blank"); },
    onError: (e: Error) => toast.error(e.message),
  });

  const pendingCount = pending?.length ?? data?.pending_submissions ?? 0;
  const preview = (pending ?? []).slice(0, 3);

  const cards = [
    { label: "Revenue", value: formatPrice(data?.revenue_cents ?? 0), sub: "All time", icon: DollarSign, accent: "text-primary" },
    { label: "This Month", value: formatPrice(data?.revenue_month_cents ?? 0), sub: "This month", icon: TrendingUp, accent: "text-primary" },
    { label: "Users", value: data?.total_users ?? 0, sub: `${data?.active_users_month ?? 0} active this month`, icon: Users },
    { label: "Logged In", value: data?.users_online ?? 0, sub: "Active in last 15 min", icon: Wifi, accent: "text-primary" },
    { label: "Logged Out", value: data?.users_offline ?? 0, sub: "Currently offline", icon: WifiOff },
    { label: "Orders", value: data?.completed_orders ?? 0, sub: "Completed orders", icon: ShoppingBag },
    { label: "Downloads", value: data?.total_downloads ?? 0, sub: `${data?.published_templates ?? 0} published`, icon: Download },
    { label: "Submissions", value: data?.pending_submissions ?? 0, sub: "Pending submissions", icon: FileUp },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Overview</h1>
        <p className="text-sm text-muted-foreground">Marketplace at a glance.</p>
      </div>

      <div className="grid gap-3 grid-cols-2 sm:gap-4 md:grid-cols-3 lg:grid-cols-4">
        {cards.map((s) => (
          <Card key={s.label}>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-xs sm:text-sm text-muted-foreground">{s.label}</CardTitle>
              <s.icon className={`h-4 w-4 ${s.accent ?? "text-muted-foreground"}`} />
            </CardHeader>
            <CardContent>
              <div className="text-xl sm:text-2xl font-bold">{s.value}</div>
              <p className="mt-1 text-[11px] sm:text-xs text-muted-foreground">{s.sub}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Submitted templates bar */}
      <Card>
        <CardHeader className="flex flex-row items-start justify-between gap-4">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Inbox className="h-5 w-5 text-primary" /> Submitted Templates
            </CardTitle>
            <CardDescription>
              {pendingCount} pending submission{pendingCount === 1 ? "" : "s"} from users
            </CardDescription>
          </div>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button variant="link" className="text-primary">See all</Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Pending template submissions</DialogTitle>
                <DialogDescription>
                  Tap a submission to view its full details. Scroll through the list below.
                </DialogDescription>
              </DialogHeader>
              <ScrollArea className="h-[60vh] pr-3">
                {(!pending || pending.length === 0) ? (
                  <div className="py-10 text-center text-sm text-muted-foreground">No pending submissions.</div>
                ) : (
                  <ul className="space-y-3">
                    {pending.map((s) => (
                      <li key={s.id}>
                        <button
                          type="button"
                          onClick={() => setSelected(s as PendingSub)}
                          className="w-full rounded-lg border border-border bg-card/50 p-4 text-left transition-colors hover:border-primary/50 hover:bg-card"
                        >
                          <div className="flex items-start justify-between gap-3">
                            <div className="min-w-0 flex-1">
                              <p className="truncate font-medium">{s.title}</p>
                              <p className="mt-0.5 text-xs text-muted-foreground">
                                {s.discord_username} · {new Date(s.created_at).toLocaleString()}
                              </p>
                              {s.description && (
                                <p className="mt-2 text-sm text-muted-foreground line-clamp-2">{s.description}</p>
                              )}
                            </div>
                            <span className="shrink-0 text-xs text-primary">View info →</span>
                          </div>
                        </button>
                      </li>
                    ))}
                  </ul>
                )}
              </ScrollArea>
            </DialogContent>
          </Dialog>
        </CardHeader>
        <CardContent>
          {preview.length === 0 ? (
            <div className="rounded-md border border-dashed border-border py-6 text-center text-sm text-muted-foreground">
              No pending submissions yet.
            </div>
          ) : (
            <ul className="divide-y divide-border rounded-md border border-border">
              {preview.map((s) => (
                <li key={s.id} className="flex flex-wrap items-center justify-between gap-2 p-3">
                  <button
                    type="button"
                    onClick={() => setSelected(s as PendingSub)}
                    className="min-w-0 flex-1 text-left"
                  >
                    <p className="truncate text-sm font-medium hover:text-primary">{s.title}</p>
                    <p className="truncate text-xs text-muted-foreground">
                      {s.discord_username} · {new Date(s.created_at).toLocaleDateString()}
                    </p>
                  </button>
                  <div className="flex items-center gap-1">
                    <Button variant="ghost" size="sm" onClick={() => download.mutate(s.id)} disabled={download.isPending || !s.file_name}>
                      <Download className="mr-1 h-3.5 w-3.5" /> Download
                    </Button>
                    <Button variant="ghost" size="sm" onClick={() => setConfirmDelete(s as PendingSub)} className="text-destructive hover:text-destructive">
                      <Trash2 className="mr-1 h-3.5 w-3.5" /> Delete
                    </Button>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>

      {/* Info dialog (read-only) */}
      <Dialog open={!!selected} onOpenChange={(v) => !v && setSelected(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{selected?.title}</DialogTitle>
            <DialogDescription>Submission details (read-only)</DialogDescription>
          </DialogHeader>
          {selected && (
            <div className="space-y-3 text-sm">
              <InfoRow label="Discord" value={selected.discord_username} />
              <InfoRow label="Submitted" value={new Date(selected.created_at).toLocaleString()} />
              <InfoRow label="Status" value={selected.status} />
              <InfoRow label="File" value={selected.file_name || "— (no file attached)"} />
              <div>
                <p className="text-xs font-medium text-muted-foreground">Description</p>
                <p className="mt-1 whitespace-pre-wrap rounded-md border border-border bg-muted/30 p-3">
                  {selected.description || <span className="text-muted-foreground">No description</span>}
                </p>
              </div>
              <div>
                <p className="text-xs font-medium text-muted-foreground">Template idea</p>
                <p className="mt-1 whitespace-pre-wrap rounded-md border border-border bg-muted/30 p-3">
                  {selected.game_idea || <span className="text-muted-foreground">No idea provided</span>}
                </p>
              </div>
            </div>
          )}
          <DialogFooter className="flex-col gap-2 sm:flex-row">
            {selected?.file_name && (
              <Button variant="secondary" onClick={() => selected && download.mutate(selected.id)} disabled={download.isPending}>
                <Download className="mr-1.5 h-4 w-4" /> Download file
              </Button>
            )}
            <Button variant="destructive" onClick={() => selected && setConfirmDelete(selected)}>
              <Trash2 className="mr-1.5 h-4 w-4" /> Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete confirmation */}
      <AlertDialog open={!!confirmDelete} onOpenChange={(v) => !v && setConfirmDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete the submission
              {confirmDelete ? ` "${confirmDelete.title}"` : ""} and its uploaded file.
              This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={del.isPending}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => { e.preventDefault(); if (confirmDelete) del.mutate(confirmDelete.id); }}
              disabled={del.isPending}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {del.isPending ? "Deleting…" : "Delete permanently"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Boxes className="h-5 w-5 text-primary" /> Top Selling Templates
            </CardTitle>
            <CardDescription>Most downloaded templates</CardDescription>
          </CardHeader>
          <CardContent>
            {!data?.top_templates?.length ? (
              <div className="py-8 text-center text-sm text-muted-foreground">No templates yet</div>
            ) : (
              <ul className="space-y-3">
                {data.top_templates.map((t) => (
                  <li key={t.id} className="flex items-center justify-between gap-3">
                    <div className="min-w-0">
                      <p className="truncate text-sm font-medium">{t.template?.title ?? "Deleted template"}</p>
                      <p className="text-xs text-muted-foreground">{formatPrice(t.template?.price_cents ?? 0)}</p>
                    </div>
                    <span className="text-sm font-semibold text-primary">{t.count} sold</span>
                  </li>
                ))}
              </ul>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <ShoppingBag className="h-5 w-5 text-primary" /> Recent Orders
            </CardTitle>
            <CardDescription>Latest purchases</CardDescription>
          </CardHeader>
          <CardContent>
            {!data?.recent_orders?.length ? (
              <div className="py-8 text-center text-sm text-muted-foreground">No orders yet</div>
            ) : (
              <ul className="space-y-3">
                {data.recent_orders.map((o) => (
                  <li key={o.id} className="flex items-center justify-between gap-3">
                    <div className="min-w-0">
                      <p className="truncate text-sm font-medium">{o.template?.title ?? "Template"}</p>
                      <p className="text-xs text-muted-foreground">{new Date(o.created_at).toLocaleString()}</p>
                    </div>
                    <span className="text-sm font-semibold">{formatPrice(o.amount_cents ?? 0)}</span>
                  </li>
                ))}
              </ul>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function InfoRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-baseline justify-between gap-3 border-b border-border/60 pb-2">
      <span className="text-xs font-medium text-muted-foreground">{label}</span>
      <span className="truncate text-sm">{value}</span>
    </div>
  );
}
