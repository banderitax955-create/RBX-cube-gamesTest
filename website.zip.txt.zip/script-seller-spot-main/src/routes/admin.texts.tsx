import { createFileRoute } from "@tanstack/react-router";
import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { listTexts, setText, DEFAULT_TEXTS } from "@/lib/texts.functions";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Save } from "lucide-react";

export const Route = createFileRoute("/admin/texts")({
  component: AdminTexts,
});

const LABELS: Record<string, string> = {
  hero_tagline: "Home — small tagline (top pill)",
  hero_title: "Home — hero title",
  hero_subtitle: "Home — hero subtitle",
  hero_cta_primary: "Home — primary button",
  hero_cta_secondary: "Home — secondary button",
  home_featured_heading: "Home — featured section heading",
  store_title: "Store — page title",
  store_subtitle: "Store — page subtitle",
  submit_title: "Submit — card title",
  submit_subtitle: "Submit — card subtitle",
};

function AdminTexts() {
  const qc = useQueryClient();
  const listFn = useServerFn(listTexts);
  const { data } = useQuery({ queryKey: ["site-texts"], queryFn: () => listFn() });
  const [values, setValues] = useState<Record<string, string>>({});

  useEffect(() => { if (data) setValues(data); }, [data]);

  const saveFn = useServerFn(setText);
  const save = useMutation({
    mutationFn: (v: { key: string; value: string }) => saveFn({ data: v }),
    onSuccess: () => { toast.success("Saved"); qc.invalidateQueries({ queryKey: ["site-texts"] }); },
    onError: (e) => toast.error(e instanceof Error ? e.message : "Failed"),
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Site texts</h1>
        <p className="text-sm text-muted-foreground">Edit any headline, button label or subtitle on the site.</p>
      </div>

      <div className="grid gap-3">
        {Object.keys(DEFAULT_TEXTS).map((key) => {
          const isLong = key === "hero_subtitle" || key === "submit_subtitle";
          return (
            <Card key={key}>
              <CardContent className="space-y-2 p-4">
                <Label className="text-xs uppercase tracking-wide text-muted-foreground">{LABELS[key] ?? key}</Label>
                {isLong ? (
                  <Textarea
                    rows={2}
                    value={values[key] ?? ""}
                    onChange={(e) => setValues({ ...values, [key]: e.target.value })}
                  />
                ) : (
                  <Input value={values[key] ?? ""} onChange={(e) => setValues({ ...values, [key]: e.target.value })} />
                )}
                <div className="flex items-center justify-between gap-2">
                  <p className="text-xs text-muted-foreground">Default: {DEFAULT_TEXTS[key]}</p>
                  <Button size="sm" onClick={() => save.mutate({ key, value: values[key] ?? "" })} disabled={save.isPending}>
                    <Save className="mr-1.5 h-3.5 w-3.5" /> Save
                  </Button>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
