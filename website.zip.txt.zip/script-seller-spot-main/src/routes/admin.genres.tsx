import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { listGenres, createGenre, deleteGenre } from "@/lib/genres.functions";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Plus, Trash2 } from "lucide-react";

export const Route = createFileRoute("/admin/genres")({
  component: AdminGenres,
});

function AdminGenres() {
  const qc = useQueryClient();
  const listFn = useServerFn(listGenres);
  const { data: genres = [] } = useQuery({ queryKey: ["genres"], queryFn: () => listFn() });
  const [name, setName] = useState("");
  const [slug, setSlug] = useState("");

  const createFn = useServerFn(createGenre);
  const create = useMutation({
    mutationFn: () => createFn({ data: { name, slug } }),
    onSuccess: () => { setName(""); setSlug(""); toast.success("Genre added"); qc.invalidateQueries({ queryKey: ["genres"] }); },
    onError: (e) => toast.error(e instanceof Error ? e.message : "Failed"),
  });

  const delFn = useServerFn(deleteGenre);
  const del = useMutation({
    mutationFn: (id: string) => delFn({ data: { id } }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["genres"] }),
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Genres</h1>
        <p className="text-sm text-muted-foreground">Create the genres shown in the Store filter.</p>
      </div>

      <Card>
        <CardContent className="p-4">
          <form
            onSubmit={(e) => { e.preventDefault(); create.mutate(); }}
            className="grid gap-3 sm:grid-cols-[1fr_1fr_auto] items-end"
          >
            <div className="space-y-1">
              <Label>Name</Label>
              <Input
                value={name}
                onChange={(e) => {
                  setName(e.target.value);
                  if (!slug) setSlug(e.target.value.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, ""));
                }}
                placeholder="Obby"
                required
              />
            </div>
            <div className="space-y-1">
              <Label>Slug</Label>
              <Input value={slug} onChange={(e) => setSlug(e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, "-"))} placeholder="obby" required />
            </div>
            <Button type="submit" disabled={create.isPending}>
              <Plus className="mr-1.5 h-4 w-4" /> Add genre
            </Button>
          </form>
        </CardContent>
      </Card>

      {genres.length === 0 ? (
        <Card><CardContent className="py-12 text-center text-muted-foreground">No genres yet.</CardContent></Card>
      ) : (
        <div className="grid gap-2">
          {genres.map((g) => (
            <Card key={g.id}>
              <CardContent className="flex items-center justify-between p-3">
                <div>
                  <p className="font-medium">{g.name}</p>
                  <p className="text-xs text-muted-foreground">{g.slug}</p>
                </div>
                <Button size="icon" variant="ghost" onClick={() => confirm("Delete genre?") && del.mutate(g.id)}>
                  <Trash2 className="h-4 w-4" />
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
