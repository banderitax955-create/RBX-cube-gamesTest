import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { SiteHeader } from "@/components/site-header";
import { listPublishedTemplates } from "@/lib/templates.functions";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { formatPrice } from "@/lib/format";
import { Sparkles, ArrowRight, Package } from "lucide-react";
import { useTexts } from "@/hooks/use-texts";

export const Route = createFileRoute("/")({
  component: Home,
});

function Home() {
  const fn = useServerFn(listPublishedTemplates);
  const { data: templates = [], isLoading } = useQuery({ queryKey: ["templates", "featured"], queryFn: () => fn() });
  const featured = templates.slice(0, 6);
  const t = useTexts();

  return (
    <div className="min-h-screen">
      <SiteHeader />
      <main>
        <section className="mx-auto max-w-7xl px-4 py-24 md:py-32">
          <div className="mx-auto max-w-3xl text-center">
            <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-border/60 bg-card/50 px-3 py-1 text-xs text-muted-foreground">
              <Sparkles className="h-3.5 w-3.5 text-primary" /> {t("hero_tagline")}
            </div>
            <h1 className="text-5xl font-bold tracking-tight md:text-6xl">
              {t("hero_title")}
            </h1>
            <p className="mt-6 text-lg text-muted-foreground">
              {t("hero_subtitle")}
            </p>
            <div className="mt-8 flex flex-wrap justify-center gap-3">
              <Button asChild size="lg">
                <Link to="/store">{t("hero_cta_primary")} <ArrowRight className="ml-2 h-4 w-4" /></Link>
              </Button>
              <Button asChild size="lg" variant="secondary">
                <Link to="/submit">{t("hero_cta_secondary")}</Link>
              </Button>
            </div>
          </div>
        </section>

        <section className="mx-auto max-w-7xl px-4 pb-24">
          <div className="mb-6 flex items-end justify-between">
            <h2 className="text-2xl font-semibold">{t("home_featured_heading")}</h2>
            <Link to="/store" className="text-sm text-muted-foreground hover:text-foreground">View all →</Link>
          </div>

          {isLoading ? (
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {Array.from({ length: 3 }).map((_, i) => (
                <div key={i} className="h-64 animate-pulse rounded-xl bg-card/50" />
              ))}
            </div>
          ) : featured.length === 0 ? (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-20 text-center">
                <Package className="mb-4 h-10 w-10 text-muted-foreground" />
                <h3 className="text-lg font-medium">No templates yet</h3>
                <p className="mt-1 text-sm text-muted-foreground">Check back soon — new templates are on the way.</p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {featured.map((t) => (
                <TemplateCard key={t.id} t={t} />
              ))}
            </div>
          )}
        </section>
      </main>
    </div>
  );
}

export function TemplateCard({ t }: { t: { slug: string; title: string; description: string; price_cents: number; thumbnail_signed: string | null } }) {
  return (
    <Link to="/templates/$slug" params={{ slug: t.slug }} className="group block">
      <Card className="overflow-hidden transition-all group-hover:border-primary/50 group-hover:shadow-lg">
        <div className="aspect-video overflow-hidden bg-muted">
          {t.thumbnail_signed ? (
            <img src={t.thumbnail_signed} alt={t.title} className="h-full w-full object-cover transition-transform group-hover:scale-105" />
          ) : (
            <div className="flex h-full w-full items-center justify-center text-muted-foreground">
              <Package className="h-8 w-8" />
            </div>
          )}
        </div>
        <CardContent className="p-4">
          <div className="flex items-start justify-between gap-2">
            <h3 className="font-semibold">{t.title}</h3>
            <span className="rounded-md bg-primary/15 px-2 py-0.5 text-sm font-medium text-primary">{formatPrice(t.price_cents)}</span>
          </div>
          <p className="mt-1 line-clamp-2 text-sm text-muted-foreground">{t.description || "No description."}</p>
        </CardContent>
      </Card>
    </Link>
  );
}
