import { createFileRoute, Link, Outlet } from "@tanstack/react-router";
import { SiteHeader } from "@/components/site-header";
import { Boxes, FileUp, LayoutDashboard, Users, Shield, Tag, Type } from "lucide-react";

export const Route = createFileRoute("/admin")({
  head: () => ({ meta: [{ title: "Admin — RBX Cube Games" }] }),
  component: AdminLayout,
});

function AdminLayout() {
  const link =
    "flex items-center gap-2 rounded-md px-3 py-2 text-sm text-muted-foreground hover:bg-secondary hover:text-foreground whitespace-nowrap";
  const active = {
    className:
      "flex items-center gap-2 rounded-md bg-secondary px-3 py-2 text-sm text-foreground whitespace-nowrap",
  };
  return (
    <div className="min-h-screen">
      <SiteHeader />
      <div className="mx-auto flex max-w-7xl flex-col gap-4 px-4 py-6 md:flex-row md:gap-6 md:py-8">
        <aside className="md:w-56 md:shrink-0">
          <div className="mb-2 flex items-center gap-2 px-2 text-sm font-semibold md:mb-3">
            <Shield className="h-4 w-4 text-primary" /> Admin
          </div>
          <nav className="-mx-1 flex gap-1 overflow-x-auto px-1 md:mx-0 md:flex-col md:space-y-1 md:overflow-visible md:px-0">
            <Link to="/admin" activeOptions={{ exact: true }} activeProps={active} className={link}>
              <LayoutDashboard className="h-4 w-4" /> Overview
            </Link>
            <Link to="/admin/templates" activeProps={active} className={link}>
              <Boxes className="h-4 w-4" /> Templates
            </Link>
            <Link to="/admin/submissions" activeProps={active} className={link}>
              <FileUp className="h-4 w-4" /> Submissions
            </Link>
            <Link to="/admin/genres" activeProps={active} className={link}>
              <Tag className="h-4 w-4" /> Genres
            </Link>
            <Link to="/admin/texts" activeProps={active} className={link}>
              <Type className="h-4 w-4" /> Site texts
            </Link>
            <Link to="/admin/users" activeProps={active} className={link}>
              <Users className="h-4 w-4" /> Users
            </Link>
          </nav>
        </aside>
        <main className="min-w-0 flex-1">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
