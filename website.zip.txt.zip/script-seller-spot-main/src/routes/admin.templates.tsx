import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { listAllTemplatesAdmin, createTemplate, updateTemplate, deleteTemplate, adminUploadFile } from "@/lib/templates.functions";
import { listGenres } from "@/lib/genres.functions";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { fileToBase64, formatPrice } from "@/lib/format";
import { Plus, Trash2, Pencil } from "lucide-react";

export const Route = createFileRoute("/admin/templates")({
  component: AdminTemplates,
});

type Template = Awaited<ReturnType<typeof listAllTemplatesAdmin>>[number];

function AdminTemplates() {
  const qc = useQueryClient();
  const listFn = useServerFn(listAllTemplatesAdmin);
  const { data: templates = [] } = useQuery({ queryKey: ["admin-templates"], queryFn: () => listFn() });

  const [editing, setEditing] = useState<Template | null>(null);
  const [open, setOpen] = useState(false);

  const delFn = useServerFn(deleteTemplate);
  const del = useMutation({
    mutationFn: (id: string) => delFn({ data: { id } }),
    onSuccess: () => { toast.success("Deleted"); qc.invalidateQueries({ queryKey: ["admin-templates"] }); },
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div><h1 className="text-2xl font-bold">Templates</h1><p className="text-sm text-muted-foreground">Add and manage store templates.</p></div>
        <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (!o) setEditing(null); }}>
          <DialogTrigger asChild><Button onClick={() => setEditing(null)}><Plus className="mr-1.5 h-4 w-4" /> New template</Button></DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader><DialogTitle>{editing ? "Edit template" : "New template"}</DialogTitle></DialogHeader>
            <TemplateForm template={editing} onDone={() => { setOpen(false); setEditing(null); qc.invalidateQueries({ queryKey: ["admin-templates"] }); }} />
          </DialogContent>
        </Dialog>
      </div>

      {templates.length === 0 ? (
        <Card><CardContent className="py-16 text-center text-muted-foreground">No templates yet. Click "New template" to add one.</CardContent></Card>
      ) : (
        <div className="grid gap-3">
          {templates.map((t) => (
            <Card key={t.id}>
              <CardContent className="flex items-center gap-4 p-4">
                <div className="h-16 w-24 shrink-0 overflow-hidden rounded-md bg-muted">
                  {t.thumbnail_signed && <img src={t.thumbnail_signed} alt="" className="h-full w-full object-cover" />}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <p className="truncate font-medium">{t.title}</p>
                    <Badge variant={t.is_published ? "default" : "secondary"}>{t.is_published ? "Published" : "Draft"}</Badge>
                  </div>
                  <p className="text-xs text-muted-foreground">{t.slug} · {formatPrice(t.price_cents)} · {t.file_path ? "file ✓" : "no file"}</p>
                </div>
                <Button size="icon" variant="ghost" onClick={() => { setEditing(t); setOpen(true); }}><Pencil className="h-4 w-4" /></Button>
                <Button size="icon" variant="ghost" onClick={() => confirm("Delete this template?") && del.mutate(t.id)}><Trash2 className="h-4 w-4" /></Button>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

function TemplateForm({ template, onDone }: { template: Template | null; onDone: () => void }) {
  const [title, setTitle] = useState(template?.title ?? "");
  const [slug, setSlug] = useState(template?.slug ?? "");
  const [description, setDescription] = useState(template?.description ?? "");
  const [price, setPrice] = useState(((template?.price_cents ?? 0) / 100).toString());
  const [youtube, setYoutube] = useState(template?.youtube_url ?? "");
  const [genreId, setGenreId] = useState<string | null>(template?.genre_id ?? null);
  const [published, setPublished] = useState(template?.is_published ?? false);
  const [thumbnailPath, setThumbnailPath] = useState<string | null>(template?.thumbnail_url ?? null);
  const [screenshotPaths, setScreenshotPaths] = useState<string[]>(template?.screenshots ?? []);
  const [filePath, setFilePath] = useState<string | null>(template?.file_path ?? null);
  const [uploading, setUploading] = useState(false);

  const uploadFn = useServerFn(adminUploadFile);
  const createFn = useServerFn(createTemplate);
  const updateFn = useServerFn(updateTemplate);
  const genresFn = useServerFn(listGenres);
  const { data: genres = [] } = useQuery({ queryKey: ["genres"], queryFn: () => genresFn() });

  const TEMPLATE_EXT = [".rbxl", ".rbxlx", ".rbxm"];
  const MAX_TEMPLATE_SIZE = 100 * 1024 * 1024;
  const IMAGE_TYPE = /^image\//;

  const upload = async (file: File, bucket: "template-files" | "template-images") => {
    if (bucket === "template-files") {
      const lower = file.name.toLowerCase();
      if (!TEMPLATE_EXT.some((e) => lower.endsWith(e))) {
        toast.error("Template file must be .rbxl, .rbxlx, or .rbxm");
        throw new Error("Invalid file type");
      }
      if (file.size > MAX_TEMPLATE_SIZE) {
        toast.error("Max 100MB");
        throw new Error("File too large");
      }
    } else if (!IMAGE_TYPE.test(file.type)) {
      toast.error("Please upload an image file");
      throw new Error("Invalid file type");
    }
    setUploading(true);
    try {
      const b64 = await fileToBase64(file);
      const path = `${crypto.randomUUID()}-${file.name.replace(/[^a-zA-Z0-9._-]/g, "_")}`;
      const r = await uploadFn({ data: { bucket, path, base64: b64, content_type: file.type || "application/octet-stream" } });
      return r.path;
    } finally { setUploading(false); }
  };

  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const price_cents = Math.round(parseFloat(price || "0") * 100);
      const base = {
        title, slug, description, price_cents,
        youtube_url: youtube || null, genre_id: genreId, is_published: published,
      };
      if (template) {
        await updateFn({ data: { id: template.id, patch: { ...base, thumbnail_url: thumbnailPath, screenshots: screenshotPaths, file_path: filePath } } });
      } else {
        const created = await createFn({ data: base });
        if (thumbnailPath || screenshotPaths.length || filePath) {
          await updateFn({ data: { id: created.id, patch: { thumbnail_url: thumbnailPath, screenshots: screenshotPaths, file_path: filePath } } });
        }
      }
      toast.success("Saved");
      onDone();
    } catch (e) { toast.error(e instanceof Error ? e.message : "Failed"); }
  };

  return (
    <form onSubmit={save} className="space-y-3 max-h-[70vh] overflow-y-auto pr-1">
      <div className="grid gap-3 sm:grid-cols-2">
        <div className="space-y-1"><Label>Title</Label><Input value={title} onChange={(e) => setTitle(e.target.value)} required /></div>
        <div className="space-y-1"><Label>Slug</Label><Input value={slug} onChange={(e) => setSlug(e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, "-"))} required /></div>
      </div>
      <div className="space-y-1"><Label>Description</Label><Textarea value={description} onChange={(e) => setDescription(e.target.value)} rows={4} /></div>
      <div className="grid gap-3 sm:grid-cols-3">
        <div className="space-y-1"><Label>Price (USD)</Label><Input type="number" min="0" step="0.01" value={price} onChange={(e) => setPrice(e.target.value)} /></div>
        <div className="space-y-1 sm:col-span-2"><Label>YouTube URL</Label><Input value={youtube} onChange={(e) => setYoutube(e.target.value)} placeholder="https://youtube.com/watch?v=…" /></div>
      </div>
      <div className="space-y-1">
        <Label>Genre</Label>
        <Select value={genreId ?? "none"} onValueChange={(v) => setGenreId(v === "none" ? null : v)}>
          <SelectTrigger><SelectValue placeholder="No genre" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="none">No genre</SelectItem>
            {genres.map((g) => <SelectItem key={g.id} value={g.id}>{g.name}</SelectItem>)}
          </SelectContent>
        </Select>
        {genres.length === 0 && <p className="text-xs text-muted-foreground">Add genres in the admin Genres page.</p>}
      </div>

      <div className="space-y-1">
        <Label>Thumbnail image</Label>
        <Input type="file" accept="image/*" onChange={async (e) => { const f = e.target.files?.[0]; if (f) setThumbnailPath(await upload(f, "template-images")); }} />
        {thumbnailPath && <p className="text-xs text-muted-foreground">✓ {thumbnailPath}</p>}
      </div>

      <div className="space-y-1">
        <Label>Screenshots (multi-select)</Label>
        <Input type="file" accept="image/*" multiple onChange={async (e) => {
          const files = Array.from(e.target.files ?? []);
          const paths: string[] = [];
          for (const f of files) paths.push(await upload(f, "template-images"));
          setScreenshotPaths([...screenshotPaths, ...paths]);
        }} />
        {screenshotPaths.length > 0 && (
          <div className="flex flex-wrap gap-1 pt-1">
            {screenshotPaths.map((p) => (
              <button key={p} type="button" onClick={() => setScreenshotPaths(screenshotPaths.filter((x) => x !== p))} className="rounded bg-secondary px-2 py-0.5 text-xs">{p.slice(0, 20)}… ✕</button>
            ))}
          </div>
        )}
      </div>

      <div className="space-y-1">
        <Label>Template file (.rbxl / .rbxlx / .rbxm)</Label>
        <Input type="file" accept=".rbxl,.rbxlx,.rbxm" onChange={async (e) => { const f = e.target.files?.[0]; if (f) setFilePath(await upload(f, "template-files")); }} />
        {filePath && <p className="text-xs text-muted-foreground">✓ {filePath}</p>}
      </div>

      <div className="flex items-center justify-between rounded-md border border-border p-3">
        <div><p className="text-sm font-medium">Published</p><p className="text-xs text-muted-foreground">Visible in the store.</p></div>
        <Switch checked={published} onCheckedChange={setPublished} />
      </div>

      <Button type="submit" className="w-full" disabled={uploading}>{uploading ? "Uploading…" : "Save template"}</Button>
    </form>
  );
}
