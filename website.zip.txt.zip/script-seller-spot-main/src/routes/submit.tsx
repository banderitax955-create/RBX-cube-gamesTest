import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { SiteHeader } from "@/components/site-header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { submitTemplate } from "@/lib/submissions.functions";
import { useSession } from "@/hooks/use-session";
import { fileToBase64 } from "@/lib/format";
import { Gift, UploadCloud } from "lucide-react";

export const Route = createFileRoute("/submit")({
  head: () => ({ meta: [{ title: "Submit your template — RBX Cube Games" }, { name: "description", content: "Submit your Roblox template and get one from us for free." }] }),
  component: Submit,
});

const ALLOWED = [".rbxl", ".rbxlx", ".rbxm"];
const MAX = 100 * 1024 * 1024;

function Submit() {
  const { user } = useSession();
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [discord, setDiscord] = useState("@");
  const [idea, setIdea] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [dragOver, setDragOver] = useState(false);
  const [done, setDone] = useState(false);

  const pickFile = (f: File | null | undefined) => {
    if (!f) return;
    const lower = f.name.toLowerCase();
    if (!ALLOWED.some((e) => lower.endsWith(e))) {
      toast.error("Only .rbxl, .rbxlx, .rbxm accepted");
      return;
    }
    if (f.size > MAX) {
      toast.error("Max 100MB");
      return;
    }
    setFile(f);
  };

  const fn = useServerFn(submitTemplate);
  const mut = useMutation({
    mutationFn: async () => {
      if (!file) throw new Error("Please attach your template file (.rbxl, .rbxlx, .rbxm)");
      const lower = file.name.toLowerCase();
      if (!ALLOWED.some((e) => lower.endsWith(e))) throw new Error("Only .rbxl, .rbxlx, .rbxm accepted");
      if (file.size > MAX) throw new Error("Max 100MB");
      const b64 = await fileToBase64(file);
      return fn({ data: {
        title, description, discord_username: discord, game_idea: idea || null,
        file_name: file.name, file_size: file.size, file_base64: b64,
      } });
    },
    onSuccess: () => setDone(true),
    onError: (e) => toast.error(e instanceof Error ? e.message : "Failed"),
  });

  if (!user) {
    return (
      <div className="min-h-screen"><SiteHeader />
        <main className="mx-auto max-w-xl px-4 py-16 text-center">
          <h1 className="text-2xl font-bold">Sign in to submit</h1>
          <p className="mt-2 text-muted-foreground">You need an account to submit a template.</p>
          <Button asChild className="mt-4"><Link to="/auth">Sign in</Link></Button>
        </main>
      </div>
    );
  }

  if (done) {
    return (
      <div className="min-h-screen"><SiteHeader />
        <main className="mx-auto max-w-xl px-4 py-16 text-center">
          <Gift className="mx-auto mb-4 h-10 w-10 text-primary" />
          <h1 className="text-2xl font-bold">Your template has been submitted.</h1>
          <p className="mt-2 text-muted-foreground">We will review it and contact you on Discord.</p>
          <div className="mt-6 flex justify-center gap-3">
            <Button asChild variant="secondary"><Link to="/dashboard">Go to dashboard</Link></Button>
            <Button onClick={() => { setDone(false); setTitle(""); setDescription(""); setIdea(""); setFile(null); }}>Submit another</Button>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen"><SiteHeader />
      <main className="mx-auto max-w-2xl px-4 py-10">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2"><Gift className="h-5 w-5 text-primary" /> Submit your template</CardTitle>
            <p className="text-sm text-muted-foreground">Send us your Roblox template and get one template from us for FREE.</p>
          </CardHeader>
          <CardContent>
            <form onSubmit={(e) => { e.preventDefault(); mut.mutate(); }} className="space-y-4">
              <div className="space-y-1"><Label>Template Name</Label>
                <Input value={title} onChange={(e) => setTitle(e.target.value)} maxLength={200} required /></div>
              <div className="space-y-1"><Label>Description</Label>
                <Textarea value={description} onChange={(e) => setDescription(e.target.value)} maxLength={3000} rows={4} /></div>
              <div className="space-y-1"><Label>Discord Username</Label>
                <Input value={discord} onChange={(e) => setDiscord(e.target.value)} placeholder="@username" required />
                <p className="text-xs text-muted-foreground">Format: @username</p></div>
              <div className="space-y-1"><Label>Template Idea (optional)</Label>
                <Textarea value={idea} onChange={(e) => setIdea(e.target.value)} maxLength={2000} rows={3} placeholder="What is your template idea?" /></div>
              <div className="space-y-1"><Label>File <span className="text-destructive">*</span></Label>
                <label
                  onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
                  onDragEnter={(e) => { e.preventDefault(); setDragOver(true); }}
                  onDragLeave={() => setDragOver(false)}
                  onDrop={(e) => {
                    e.preventDefault();
                    setDragOver(false);
                    pickFile(e.dataTransfer.files?.[0]);
                  }}
                  className={`flex cursor-pointer flex-col items-center justify-center rounded-lg border-2 border-dashed p-8 text-center transition-colors ${dragOver ? "border-primary bg-primary/5" : "border-border bg-card/50 hover:border-primary/50 hover:bg-card"}`}
                >
                  <UploadCloud className={`mb-2 h-8 w-8 ${dragOver ? "text-primary" : "text-muted-foreground"}`} />
                  <p className="text-sm font-medium">
                    {file ? file.name : "Drag & drop your file here"}
                  </p>
                  <p className="mt-1 text-xs text-muted-foreground">
                    {file
                      ? `${(file.size / 1024 / 1024).toFixed(2)} MB · click to change`
                      : "or click to browse"}
                  </p>
                  <input
                    type="file"
                    accept=".rbxl,.rbxlx,.rbxm"
                    onChange={(e) => pickFile(e.target.files?.[0])}
                    className="hidden"
                  />
                </label>
                <p className="text-xs text-muted-foreground">Accepted formats: .rbxl, .rbxlx, .rbxm only — max 100MB</p></div>
              <Button type="submit" className="w-full" disabled={mut.isPending}>
                {mut.isPending ? "Uploading…" : "Submit template"}
              </Button>
            </form>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
