import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { listUsersAdmin } from "@/lib/admin.functions";
import { Card, CardContent } from "@/components/ui/card";
import { formatPrice } from "@/lib/format";

export const Route = createFileRoute("/admin/users")({
  component: AdminUsers,
});

function AdminUsers() {
  const fn = useServerFn(listUsersAdmin);
  const { data: users = [] } = useQuery({ queryKey: ["admin-users"], queryFn: () => fn() });

  return (
    <div className="space-y-6">
      <div><h1 className="text-2xl font-bold">Users</h1><p className="text-sm text-muted-foreground">All registered users and their purchase activity.</p></div>
      {users.length === 0 ? (
        <Card><CardContent className="py-16 text-center text-muted-foreground">No users yet.</CardContent></Card>
      ) : (
        <Card>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="border-b border-border text-left text-xs uppercase text-muted-foreground">
                <tr>
                  <th className="px-4 py-3">Email</th>
                  <th className="px-4 py-3">Display</th>
                  <th className="px-4 py-3">Discord</th>
                  <th className="px-4 py-3">Purchases</th>
                  <th className="px-4 py-3">Spent</th>
                  <th className="px-4 py-3">Joined</th>
                </tr>
              </thead>
              <tbody>
                {users.map((u) => (
                  <tr key={u.id} className="border-b border-border/50 last:border-0">
                    <td className="px-4 py-3">{u.email}</td>
                    <td className="px-4 py-3">{u.display_name || "—"}</td>
                    <td className="px-4 py-3">{u.discord_username || "—"}</td>
                    <td className="px-4 py-3">{u.purchases}</td>
                    <td className="px-4 py-3">{formatPrice(u.spent_cents)}</td>
                    <td className="px-4 py-3 text-muted-foreground">{new Date(u.created_at).toLocaleDateString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      )}
    </div>
  );
}
