import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export const listMyOrders = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("orders")
      .select("id, template_id, amount_cents, status, created_at, templates:template_id(title, slug, thumbnail_url)")
      .eq("user_id", context.userId)
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);
    return data ?? [];
  });

export const getPurchaseDownloadUrl = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i: unknown) => z.object({ template_id: z.string().uuid() }).parse(i))
  .handler(async ({ data, context }) => {
    const { data: order } = await context.supabase
      .from("orders")
      .select("id, status")
      .eq("user_id", context.userId)
      .eq("template_id", data.template_id)
      .eq("status", "paid")
      .maybeSingle();
    if (!order) throw new Error("You have not purchased this template");
    const { data: tmpl } = await context.supabase.from("templates").select("file_path").eq("id", data.template_id).maybeSingle();
    if (!tmpl?.file_path) throw new Error("No file available");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: signed, error } = await supabaseAdmin.storage.from("template-files").createSignedUrl(tmpl.file_path, 60);
    if (error || !signed) throw new Error(error?.message || "Failed to create link");
    return { url: signed.signedUrl };
  });

// Simple test-mode "buy" that marks the order paid immediately.
// Replace with Stripe Checkout once payments are enabled.
export const purchaseTemplateTestMode = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i: unknown) => z.object({ template_id: z.string().uuid() }).parse(i))
  .handler(async ({ data, context }) => {
    const { data: tmpl } = await context.supabase.from("templates").select("id, price_cents, is_published").eq("id", data.template_id).maybeSingle();
    if (!tmpl || !tmpl.is_published) throw new Error("Template not available");
    const { data: existing } = await context.supabase
      .from("orders").select("id, status").eq("user_id", context.userId).eq("template_id", data.template_id).eq("status", "paid").maybeSingle();
    if (existing) return { order_id: existing.id, already: true };
    const { data: row, error } = await context.supabase.from("orders").insert({
      user_id: context.userId,
      template_id: data.template_id,
      amount_cents: tmpl.price_cents,
      status: "paid",
      stripe_session_id: `test_${crypto.randomUUID()}`,
    }).select().single();
    if (error) throw new Error(error.message);
    return { order_id: row.id, already: false };
  });
