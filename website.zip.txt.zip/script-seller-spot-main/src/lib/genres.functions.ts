import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { createClient } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";

function publicClient() {
  return createClient<Database>(process.env.SUPABASE_URL!, process.env.SUPABASE_PUBLISHABLE_KEY!, {
    auth: { storage: undefined, persistSession: false, autoRefreshToken: false },
  });
}

export const listGenres = createServerFn({ method: "GET" }).handler(async () => {
  const supa = publicClient();
  const { data, error } = await supa.from("genres").select("id, name, slug").order("name");
  if (error) throw new Error(error.message);
  return (data ?? []) as { id: string; name: string; slug: string }[];
});

const genreSchema = z.object({
  name: z.string().trim().min(1).max(80),
  slug: z.string().trim().regex(/^[a-z0-9-]+$/).max(80),
});

export const createGenre = createServerFn({ method: "POST" })
  .inputValidator((i: unknown) => genreSchema.parse(i))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: row, error } = await supabaseAdmin.from("genres").insert(data).select().single();
    if (error) throw new Error(error.message);
    return row;
  });

export const deleteGenre = createServerFn({ method: "POST" })
  .inputValidator((i: unknown) => z.object({ id: z.string().uuid() }).parse(i))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.from("genres").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });
