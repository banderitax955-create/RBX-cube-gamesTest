import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

async function admin() {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  return supabaseAdmin;
}

export const getAdminStats = createServerFn({ method: "GET" }).handler(async () => {
  const supabaseAdmin = await admin();

  const now = new Date();
  const monthStart = new Date(now.getFullYear(), now.getMonth(), 1).toISOString();
  const onlineThreshold = new Date(now.getTime() - 15 * 60 * 1000); // 15 min

  // Fetch auth users for online/offline counts
  let onlineUsers = 0;
  let offlineUsers = 0;
  try {
    const { data: authList } = await supabaseAdmin.auth.admin.listUsers({ page: 1, perPage: 1000 });
    for (const u of authList?.users ?? []) {
      const last = u.last_sign_in_at ? new Date(u.last_sign_in_at) : null;
      if (last && last >= onlineThreshold) onlineUsers += 1;
      else offlineUsers += 1;
    }
  } catch {
    // ignore
  }


  const [orders, users, subs, comm, tmpls, tmplList] = await Promise.all([
    supabaseAdmin.from("orders").select("id, user_id, template_id, amount_cents, status, created_at"),
    supabaseAdmin.from("profiles").select("id, created_at"),
    supabaseAdmin.from("template_submissions").select("id, status", { count: "exact" }),
    supabaseAdmin.from("community_games").select("id", { count: "exact", head: true }),
    supabaseAdmin.from("templates").select("id, title, slug, is_published"),
    supabaseAdmin.from("templates").select("id, title, slug, price_cents, thumbnail_url, is_published"),
  ]);

  const allOrders = orders.data ?? [];
  const paid = allOrders.filter((o) => o.status === "paid");
  const paidMonth = paid.filter((o) => o.created_at >= monthStart);

  const revenue = paid.reduce((s, o) => s + (o.amount_cents ?? 0), 0);
  const revenueMonth = paidMonth.reduce((s, o) => s + (o.amount_cents ?? 0), 0);

  const activeUserIds = new Set(paidMonth.map((o) => o.user_id));
  const totalUsers = (users.data ?? []).length;

  const publishedCount = (tmpls.data ?? []).filter((t) => t.is_published).length;
  const totalTemplates = (tmpls.data ?? []).length;

  const pendingSubs = (subs.data ?? []).filter((s) => s.status === "pending").length;

  const byTemplate = new Map<string, number>();
  paid.forEach((o) => {
    if (!o.template_id) return;
    byTemplate.set(o.template_id, (byTemplate.get(o.template_id) ?? 0) + 1);
  });
  const tmap = new Map((tmplList.data ?? []).map((t) => [t.id, t]));
  const top = [...byTemplate.entries()]
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5)
    .map(([id, count]) => ({ id, count, template: tmap.get(id) ?? null }));

  const recentOrders = [...paid]
    .sort((a, b) => (a.created_at < b.created_at ? 1 : -1))
    .slice(0, 5)
    .map((o) => ({
      id: o.id,
      amount_cents: o.amount_cents,
      created_at: o.created_at,
      template: o.template_id ? tmap.get(o.template_id) ?? null : null,
    }));

  return {
    revenue_cents: revenue,
    revenue_month_cents: revenueMonth,
    total_users: totalUsers,
    active_users_month: activeUserIds.size,
    total_purchases: paid.length,
    completed_orders: paid.length,
    total_downloads: paid.length,
    total_templates: totalTemplates,
    published_templates: publishedCount,
    total_submissions: subs.count ?? 0,
    pending_submissions: pendingSubs,
    total_community: comm.count ?? 0,
    users_online: onlineUsers,
    users_offline: offlineUsers,
    top_templates: top,
    recent_orders: recentOrders,
  };
});

export const listPendingSubmissionsAdmin = createServerFn({ method: "GET" }).handler(async () => {
  const supabaseAdmin = await admin();
  const { data, error } = await supabaseAdmin
    .from("template_submissions")
    .select("id, title, description, discord_username, game_idea, status, created_at, file_name, user_id")
    .eq("status", "pending")
    .order("created_at", { ascending: false });
  if (error) throw new Error(error.message);
  return data ?? [];
});

export const deleteSubmissionAdmin = createServerFn({ method: "POST" })
  .inputValidator((i: unknown) => z.object({ id: z.string().uuid() }).parse(i))
  .handler(async ({ data }) => {
    const supabaseAdmin = await admin();
    const { data: row } = await supabaseAdmin.from("template_submissions").select("file_path").eq("id", data.id).maybeSingle();
    if (row?.file_path) {
      await supabaseAdmin.storage.from("submissions").remove([row.file_path]);
    }
    const { error } = await supabaseAdmin.from("template_submissions").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const listUsersAdmin = createServerFn({ method: "GET" }).handler(async () => {
  const supabaseAdmin = await admin();
  const { data: profiles } = await supabaseAdmin.from("profiles").select("id, email, display_name, discord_username, created_at").order("created_at", { ascending: false });
  const { data: orders } = await supabaseAdmin.from("orders").select("user_id, amount_cents, status");
  const byUser = new Map<string, { count: number; spent: number }>();
  (orders ?? []).filter((o) => o.status === "paid").forEach((o) => {
    const cur = byUser.get(o.user_id) ?? { count: 0, spent: 0 };
    cur.count += 1;
    cur.spent += o.amount_cents ?? 0;
    byUser.set(o.user_id, cur);
  });
  return (profiles ?? []).map((p) => ({
    ...p,
    purchases: byUser.get(p.id)?.count ?? 0,
    spent_cents: byUser.get(p.id)?.spent ?? 0,
  }));
});
