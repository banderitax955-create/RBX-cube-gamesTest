export function formatPrice(cents: number) {
  return `$${(cents / 100).toFixed(2)}`;
}

export function fileToBase64(file: File): Promise<string> {
  return new Promise((res, rej) => {
    const r = new FileReader();
    r.onload = () => {
      const s = r.result as string;
      res(s.split(",")[1] || "");
    };
    r.onerror = () => rej(r.error);
    r.readAsDataURL(file);
  });
}
