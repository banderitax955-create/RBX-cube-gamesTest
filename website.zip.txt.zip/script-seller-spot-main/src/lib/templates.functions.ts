import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { createClient } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";


const IMAGE_BUCKET = "template-images";

function publicClient() {
  return createClient<Database>(process.env.SUPABASE_URL!, process.env.SUPABASE_PUBLISHABLE_KEY!, {
    auth: { storage: undefined, persistSession: false, autoRefreshToken: false },
  });
}

async function signImages(paths: (string | null | undefined)[]) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const clean = paths.filter((p): p is string => !!p);
  if (!clean.length) return {} as Record<string, string>;
  const { data } = await supabaseAdmin.storage.from(IMAGE_BUCKET).createSignedUrls(clean, 3600);
  const map: Record<string, string> = {};
  data?.forEach((d) => { if (d.path && d.signedUrl) map[d.path] = d.signedUrl; });
  return map;
}

export const listPublishedTemplates = createServerFn({ method: "GET" }).handler(async () => {
  const supa = publicClient();
  const { data, error } = await supa
    .from("templates")
    .select("id, title, slug, description, price_cents, thumbnail_url, screenshots, youtube_url, roblox_game_url, genre_id, created_at")
    .eq("is_published", true)
    .order("created_at", { ascending: false });
  if (error) throw new Error(error.message);
  const rows = data ?? [];
  const allPaths = rows.flatMap((r) => [r.thumbnail_url, ...(r.screenshots ?? [])]);
  const signed = await signImages(allPaths);
  return rows.map((r) => ({
    ...r,
    thumbnail_signed: r.thumbnail_url ? signed[r.thumbnail_url] ?? null : null,
    screenshots_signed: (r.screenshots ?? []).map((s) => signed[s]).filter(Boolean) as string[],
  }));
});

export const getTemplateBySlug = createServerFn({ method: "GET" })
  .inputValidator((i: unknown) => z.object({ slug: z.string().min(1) }).parse(i))
  .handler(async ({ data }) => {
    const supa = publicClient();
    const { data: row, error } = await supa
      .from("templates")
      .select("id, title, slug, description, price_cents, thumbnail_url, screenshots, youtube_url, roblox_game_url")
      .eq("slug", data.slug)
      .eq("is_published", true)
      .maybeSingle();
    if (error) throw new Error(error.message);
    if (!row) return null;
    const signed = await signImages([row.thumbnail_url, ...(row.screenshots ?? [])]);
    return {
      ...row,
      thumbnail_signed: row.thumbnail_url ? signed[row.thumbnail_url] ?? null : null,
      screenshots_signed: (row.screenshots ?? []).map((s) => signed[s]).filter(Boolean) as string[],
    };
  });

export const listAllTemplatesAdmin = createServerFn({ method: "GET" }).handler(async () => {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data, error } = await supabaseAdmin
    .from("templates")
    .select("*")
    .order("created_at", { ascending: false });
  if (error) throw new Error(error.message);
  const rows = data ?? [];
  const signed = await signImages(rows.map((r) => r.thumbnail_url));
  return rows.map((r) => ({ ...r, thumbnail_signed: r.thumbnail_url ? signed[r.thumbnail_url] ?? null : null }));
});

const templateSchema = z.object({
  title: z.string().trim().min(1).max(200),
  slug: z.string().trim().regex(/^[a-z0-9-]+$/, "lowercase letters, digits and dashes only").max(80),
  description: z.string().max(5000).default(""),
  price_cents: z.number().int().min(0).max(1_000_000),
  youtube_url: z.string().url().max(500).nullable().optional(),
  roblox_game_url: z.string().url().max(500).nullable().optional(),
  genre_id: z.string().uuid().nullable().optional(),
  is_published: z.boolean().default(false),
});

export const createTemplate = createServerFn({ method: "POST" })
  .inputValidator((i: unknown) => templateSchema.parse(i))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: row, error } = await supabaseAdmin.from("templates").insert(data).select().single();
    if (error) throw new Error(error.message);
    return row;
  });

export const updateTemplate = createServerFn({ method: "POST" })
  .inputValidator((i: unknown) => z.object({ id: z.string().uuid(), patch: templateSchema.partial().extend({
    thumbnail_url: z.string().nullable().optional(),
    screenshots: z.array(z.string()).optional(),
    file_path: z.string().nullable().optional(),
  }) }).parse(i))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: row, error } = await supabaseAdmin.from("templates").update(data.patch).eq("id", data.id).select().single();
    if (error) throw new Error(error.message);
    return row;
  });

export const deleteTemplate = createServerFn({ method: "POST" })
  .inputValidator((i: unknown) => z.object({ id: z.string().uuid() }).parse(i))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.from("templates").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

const uploadSchema = z.object({
  bucket: z.enum(["template-files", "template-images"]),
  path: z.string().min(1).max(300),
  base64: z.string().min(1),
  content_type: z.string().max(200).default("application/octet-stream"),
});

export const adminUploadFile = createServerFn({ method: "POST" })
  .inputValidator((i: unknown) => uploadSchema.parse(i))
  .handler(async ({ data }) => {
    const bytes = Uint8Array.from(atob(data.base64), (c) => c.charCodeAt(0));
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.storage.from(data.bucket).upload(data.path, bytes, {
      contentType: data.content_type,
      upsert: true,
    });
    if (error) throw new Error(error.message);
    return { path: data.path };
  });

