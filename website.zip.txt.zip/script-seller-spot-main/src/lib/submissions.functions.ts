import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const ALLOWED_EXT = [".rbxl", ".rbxlx", ".rbxm"];
const MAX_SIZE = 100 * 1024 * 1024;

const submissionSchema = z.object({
  title: z.string().trim().min(1).max(200),
  description: z.string().trim().max(3000).default(""),
  discord_username: z.string().trim().regex(/^@[A-Za-z0-9._-]{2,32}$/, "Must be @username"),
  game_idea: z.string().trim().max(2000).optional().nullable(),
  file_name: z.string().min(1).max(300).refine(
    (n) => ALLOWED_EXT.some((e) => n.toLowerCase().endsWith(e)),
    "Only .rbxl, .rbxlx, .rbxm files are accepted",
  ),
  file_size: z.number().int().positive().max(MAX_SIZE, "Max 100MB"),
  file_base64: z.string().min(1, "File is required"),
});

const COOLDOWN_MS = 60 * 60 * 1000;

export const getSubmitCooldown = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data } = await context.supabase
      .from("template_submissions")
      .select("created_at")
      .eq("user_id", context.userId)
      .order("created_at", { ascending: false })
      .limit(1)
      .maybeSingle();
    if (!data) return { ready_at: null as string | null };
    const readyAt = new Date(new Date(data.created_at).getTime() + COOLDOWN_MS);
    return { ready_at: readyAt > new Date() ? readyAt.toISOString() : null };
  });

export const submitTemplate = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i: unknown) => submissionSchema.parse(i))
  .handler(async ({ data, context }) => {
    // 1-hour cooldown enforcement
    const { data: last } = await context.supabase
      .from("template_submissions")
      .select("created_at")
      .eq("user_id", context.userId)
      .order("created_at", { ascending: false })
      .limit(1)
      .maybeSingle();
    if (last) {
      const elapsed = Date.now() - new Date(last.created_at).getTime();
      if (elapsed < COOLDOWN_MS) {
        const mins = Math.ceil((COOLDOWN_MS - elapsed) / 60000);
        throw new Error(`Please wait ${mins} minute${mins === 1 ? "" : "s"} before submitting another template.`);
      }
    }

    // Cleanup: delete this user's rejected submissions (and any rejected older than 1h across users)
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    await supabaseAdmin.from("template_submissions").delete().eq("user_id", context.userId).eq("status", "rejected");
    await supabaseAdmin
      .from("template_submissions")
      .delete()
      .eq("status", "rejected")
      .lt("created_at", new Date(Date.now() - COOLDOWN_MS).toISOString());

    let path = "";
    let fileName = "";
    let fileSize = 0;

    if (data.file_base64 && data.file_name) {
      const lower = data.file_name.toLowerCase();
      if (!ALLOWED_EXT.some((e) => lower.endsWith(e))) {
        throw new Error("Only .rbxl, .rbxlx, .rbxm files are accepted");
      }
      const bytes = Uint8Array.from(atob(data.file_base64), (c) => c.charCodeAt(0));
      if (bytes.byteLength > MAX_SIZE) throw new Error("Max 100MB");

      path = `${context.userId}/${crypto.randomUUID()}-${data.file_name}`;
      const up = await supabaseAdmin.storage.from("submissions").upload(path, bytes, {
        contentType: "application/octet-stream",
        upsert: false,
      });
      if (up.error) throw new Error(up.error.message);
      fileName = data.file_name;
      fileSize = bytes.byteLength;
    }

    const { data: row, error } = await context.supabase.from("template_submissions").insert({
      user_id: context.userId,
      title: data.title,
      description: data.description,
      discord_username: data.discord_username,
      game_idea: data.game_idea || null,
      file_path: path,
      file_name: fileName,
      file_size: fileSize,
    }).select().single();
    if (error) throw new Error(error.message);
    return row;
  });

export const listMySubmissions = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("template_submissions")
      .select("id, title, description, discord_username, game_idea, status, created_at, file_name")
      .eq("user_id", context.userId)
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);
    const cutoff = Date.now() - COOLDOWN_MS;
    return (data ?? []).filter((s) => !(s.status === "rejected" && new Date(s.created_at).getTime() < cutoff));
  });

export const listAllSubmissionsAdmin = createServerFn({ method: "GET" }).handler(async () => {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data, error } = await supabaseAdmin
    .from("template_submissions")
    .select("*")
    .order("created_at", { ascending: false });
  if (error) throw new Error(error.message);
  return data ?? [];
});

export const setSubmissionStatus = createServerFn({ method: "POST" })
  .inputValidator((i: unknown) => z.object({ id: z.string().uuid(), status: z.enum(["pending", "approved", "rejected"]) }).parse(i))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.from("template_submissions").update({ status: data.status }).eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const getSubmissionDownloadUrl = createServerFn({ method: "POST" })
  .inputValidator((i: unknown) => z.object({ id: z.string().uuid() }).parse(i))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: row, error } = await supabaseAdmin.from("template_submissions").select("file_path").eq("id", data.id).maybeSingle();
    if (error || !row) throw new Error("Not found");
    const { data: signed, error: sErr } = await supabaseAdmin.storage.from("submissions").createSignedUrl(row.file_path, 300);
    if (sErr || !signed) throw new Error(sErr?.message || "Failed to sign");
    return { url: signed.signedUrl };
  });

