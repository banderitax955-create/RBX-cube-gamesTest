import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { createClient } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";

function publicClient() {
  return createClient<Database>(process.env.SUPABASE_URL!, process.env.SUPABASE_PUBLISHABLE_KEY!, {
    auth: { storage: undefined, persistSession: false, autoRefreshToken: false },
  });
}

export const DEFAULT_TEXTS: Record<string, string> = {
  hero_tagline: "The Cheapest Roblox Game Templates",
  hero_title: "Ship your next Roblox hit in minutes.",
  hero_subtitle: "Production-ready templates you can buy, customize, and publish. Or submit your own template and get one from us for free.",
  hero_cta_primary: "Browse the store",
  hero_cta_secondary: "Submit your template",
  home_featured_heading: "Featured templates",
  store_title: "Store",
  store_subtitle: "Browse premium Roblox game templates.",
  submit_title: "Submit your template",
  submit_subtitle: "Send us your Roblox template and get one template from us for FREE.",
};

export const listTexts = createServerFn({ method: "GET" }).handler(async () => {
  const supa = publicClient();
  const { data, error } = await supa.from("site_texts").select("key, value");
  if (error) throw new Error(error.message);
  const out: Record<string, string> = { ...DEFAULT_TEXTS };
  for (const r of (data ?? []) as { key: string; value: string }[]) out[r.key] = r.value;
  return out;
});

export const setText = createServerFn({ method: "POST" })
  .inputValidator((i: unknown) => z.object({ key: z.string().min(1).max(80), value: z.string().max(4000) }).parse(i))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.from("site_texts").upsert({ key: data.key, value: data.value, updated_at: new Date().toISOString() });
    if (error) throw new Error(error.message);
    return { ok: true };
  });
