import { Link, useNavigate } from "@tanstack/react-router";
import { Boxes, LogOut, Menu, Shield, User as UserIcon } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { useSession } from "@/hooks/use-session";

export function SiteHeader() {
  const { user } = useSession();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);

  const signOut = async () => {
    await supabase.auth.signOut();
    setOpen(false);
    navigate({ to: "/" });
  };

  const navLink = "text-muted-foreground transition-colors hover:text-foreground";
  const activeNav = { className: "text-foreground" };

  return (
    <header className="sticky top-0 z-40 w-full border-b border-border/60 bg-background/70 backdrop-blur">
      <div className="mx-auto grid h-16 max-w-7xl grid-cols-[auto_1fr_auto] items-center gap-3 px-4">
        <Link to="/" className="flex items-center gap-2 font-bold tracking-tight">
          <Boxes className="h-5 w-5 text-primary" />
          <span>RBX Cube Games</span>
        </Link>
        <nav className="hidden items-center justify-center gap-6 text-sm md:flex">
          <Link to="/store" className={navLink} activeProps={activeNav}>Store</Link>
          <Link to="/submit" className={navLink} activeProps={activeNav}>Submit</Link>
          {user && (
            <Link to="/dashboard" className={navLink} activeProps={activeNav}>Dashboard</Link>
          )}
          <Link to="/admin" className={`${navLink} flex items-center gap-1`} activeProps={activeNav}>
            <Shield className="h-3.5 w-3.5" /> Admin
          </Link>
        </nav>
        <div className="flex items-center justify-end gap-2">
          {user ? (
            <>
              <span className="hidden text-xs text-muted-foreground sm:inline-flex items-center gap-1">
                <UserIcon className="h-3.5 w-3.5" /> {user.email}
              </span>
              <Button variant="ghost" size="sm" onClick={signOut} className="hidden md:inline-flex">
                <LogOut className="h-4 w-4" />
              </Button>
            </>
          ) : (
            <Button asChild size="sm" variant="secondary" className="hidden md:inline-flex">
              <Link to="/auth">Sign in</Link>
            </Button>
          )}
          <Button
            variant="ghost"
            size="sm"
            className="md:hidden"
            aria-label="Toggle menu"
            aria-expanded={open}
            onClick={() => setOpen((v) => !v)}
          >
            <Menu className="h-5 w-5" />
          </Button>
        </div>
      </div>
      {open && (
        <div className="border-t border-border/60 bg-background/95 backdrop-blur md:hidden">
          <nav className="mx-auto flex max-w-7xl flex-col gap-1 px-4 py-3 text-sm">
            <Link to="/store" className="rounded-md px-2 py-2 hover:bg-secondary" activeProps={{ className: "rounded-md px-2 py-2 bg-secondary text-foreground" }} onClick={() => setOpen(false)}>Store</Link>
            <Link to="/submit" className="rounded-md px-2 py-2 hover:bg-secondary" activeProps={{ className: "rounded-md px-2 py-2 bg-secondary text-foreground" }} onClick={() => setOpen(false)}>Submit</Link>
            {user && (
              <Link to="/dashboard" className="rounded-md px-2 py-2 hover:bg-secondary" activeProps={{ className: "rounded-md px-2 py-2 bg-secondary text-foreground" }} onClick={() => setOpen(false)}>Dashboard</Link>
            )}
            <Link to="/admin" className="flex items-center gap-1 rounded-md px-2 py-2 hover:bg-secondary" activeProps={{ className: "flex items-center gap-1 rounded-md px-2 py-2 bg-secondary text-foreground" }} onClick={() => setOpen(false)}>
              <Shield className="h-3.5 w-3.5" /> Admin
            </Link>
            <div className="mt-2 border-t border-border/60 pt-2">
              {user ? (
                <div className="flex items-center justify-between gap-2 px-2">
                  <span className="inline-flex min-w-0 items-center gap-1 truncate text-xs text-muted-foreground">
                    <UserIcon className="h-3.5 w-3.5 shrink-0" />
                    <span className="truncate">{user.email}</span>
                  </span>
                  <Button variant="ghost" size="sm" onClick={signOut}>
                    <LogOut className="h-4 w-4" />
                  </Button>
                </div>
              ) : (
                <Button asChild size="sm" variant="secondary" className="w-full" onClick={() => setOpen(false)}>
                  <Link to="/auth">Sign in</Link>
                </Button>
              )}
            </div>
          </nav>
        </div>
      )}
    </header>
  );
}
