import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { listTexts, DEFAULT_TEXTS } from "@/lib/texts.functions";

export function useTexts() {
  const fn = useServerFn(listTexts);
  const { data } = useQuery({ queryKey: ["site-texts"], queryFn: () => fn(), staleTime: 60_000 });
  const texts = data ?? DEFAULT_TEXTS;
  return (key: string) => texts[key] ?? DEFAULT_TEXTS[key] ?? "";
}
